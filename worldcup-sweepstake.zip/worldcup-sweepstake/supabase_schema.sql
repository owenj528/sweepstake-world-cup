-- ============================================================
-- WORLD CUP SWEEPSTAKE — SUPABASE SCHEMA
-- Run this entire file in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PROFILES TABLE (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  team TEXT DEFAULT NULL,
  normal_points INTEGER DEFAULT 0,
  chaos_points INTEGER DEFAULT 0,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- CHALLENGES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  points INTEGER NOT NULL DEFAULT 5,
  icon TEXT DEFAULT '🏆',
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ DEFAULT NULL,
  completed_by_team TEXT DEFAULT NULL,
  completed_by_user_id UUID REFERENCES public.profiles(id) DEFAULT NULL,
  category TEXT DEFAULT 'general',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- MATCHES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.matches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  external_id TEXT UNIQUE,
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  home_score INTEGER DEFAULT NULL,
  away_score INTEGER DEFAULT NULL,
  date TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'scheduled', -- scheduled, live, finished
  stage TEXT DEFAULT 'group', -- group, round_of_16, quarter_final, semi_final, final
  group_name TEXT DEFAULT NULL,
  venue TEXT DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TRADES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.trades (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  requester_id UUID NOT NULL REFERENCES public.profiles(id),
  receiver_id UUID NOT NULL REFERENCES public.profiles(id),
  requester_team TEXT NOT NULL,
  receiver_team TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, accepted, rejected, cancelled
  message TEXT DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- GROUP STANDINGS TABLE (auto-populated from matches)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.group_standings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_name TEXT NOT NULL,
  team TEXT NOT NULL,
  played INTEGER DEFAULT 0,
  won INTEGER DEFAULT 0,
  drawn INTEGER DEFAULT 0,
  lost INTEGER DEFAULT 0,
  goals_for INTEGER DEFAULT 0,
  goals_against INTEGER DEFAULT 0,
  goal_difference INTEGER DEFAULT 0,
  points INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(group_name, team)
);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_standings ENABLE ROW LEVEL SECURITY;

-- Profiles: users can read all, only update their own
CREATE POLICY "profiles_read_all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Admin can update any profile (team assignment, points)
CREATE POLICY "profiles_admin_update" ON public.profiles FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

-- Challenges: everyone can read, only admin can write
CREATE POLICY "challenges_read_all" ON public.challenges FOR SELECT USING (true);
CREATE POLICY "challenges_admin_write" ON public.challenges FOR ALL
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

-- Matches: everyone can read, admin/system can write
CREATE POLICY "matches_read_all" ON public.matches FOR SELECT USING (true);
CREATE POLICY "matches_admin_write" ON public.matches FOR ALL
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

-- Trades: users can see trades they're involved in
CREATE POLICY "trades_read_own" ON public.trades FOR SELECT
  USING (auth.uid() = requester_id OR auth.uid() = receiver_id);
CREATE POLICY "trades_insert_own" ON public.trades FOR INSERT WITH CHECK (auth.uid() = requester_id);
CREATE POLICY "trades_update_involved" ON public.trades FOR UPDATE
  USING (auth.uid() = requester_id OR auth.uid() = receiver_id);

-- Group standings: everyone can read
CREATE POLICY "standings_read_all" ON public.group_standings FOR SELECT USING (true);
CREATE POLICY "standings_admin_write" ON public.group_standings FOR ALL
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = TRUE));

-- ============================================================
-- FUNCTION: auto-create profile on user signup
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email, is_admin)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    NEW.email,
    NEW.email = 'oj_2010@outlook.com'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- FUNCTION: update updated_at timestamp
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_matches_updated_at BEFORE UPDATE ON public.matches
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_trades_updated_at BEFORE UPDATE ON public.trades
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- SEED DEFAULT CHALLENGES
-- ============================================================
INSERT INTO public.challenges (name, description, points, icon, category) VALUES
  ('First Goal of Tournament', 'The very first goal scored in the tournament', 5, '⚽', 'goals'),
  ('First Red Card', 'First player to receive a red card', 10, '🟥', 'discipline'),
  ('First VAR Decision', 'First match to have a VAR intervention', 8, '📺', 'technology'),
  ('First Hat-Trick', 'First player to score a hat-trick', 15, '🎩', 'goals'),
  ('First Own Goal', 'First own goal of the tournament', 10, '😬', 'goals'),
  ('First Penalty Missed', 'First penalty kick to be missed', 7, '🥅', 'penalties'),
  ('First Penalty Shootout', 'First match to go to a penalty shootout', 12, '😰', 'penalties'),
  ('First Extra Time Match', 'First match to go to extra time', 8, '⏱️', 'time'),
  ('First Manager Yellow Card', 'First manager to receive a yellow card', 6, '👔', 'discipline'),
  ('First Knockout Team Eliminated', 'First team to be knocked out of the tournament', 12, '💀', 'knockouts'),
  ('First Upset (Lower-ranked beats Higher)', 'A lower FIFA ranked team beats a higher ranked one', 9, '😱', 'upsets'),
  ('First Golden Boot Leader', 'Team whose player first leads the Golden Boot', 6, '👟', 'awards'),
  ('First Match With 5+ Goals', 'First match where combined goals total 5 or more', 11, '🎯', 'goals'),
  ('First Disallowed Goal (VAR)', 'First goal to be disallowed by VAR', 9, '❌', 'technology'),
  ('First Injury Time Winner', 'First goal scored in 90+ minutes to win a game', 13, '🕐', 'drama')
ON CONFLICT DO NOTHING;

-- ============================================================
-- SEED WORLD CUP 2026 TEAMS (for reference)
-- ============================================================
-- Teams are assigned by admin through the app UI
-- The 48 teams for FIFA World Cup 2026:
-- Group A: USA, Panama, Honduras, Morocco (host groups)
-- This is a reference comment only - teams assigned via admin panel

-- ============================================================
-- REALTIME: Enable realtime for key tables
-- ============================================================
-- Run these in Supabase Dashboard > Database > Replication
-- Or via SQL:
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.challenges;
ALTER PUBLICATION supabase_realtime ADD TABLE public.matches;
ALTER PUBLICATION supabase_realtime ADD TABLE public.trades;
ALTER PUBLICATION supabase_realtime ADD TABLE public.group_standings;
