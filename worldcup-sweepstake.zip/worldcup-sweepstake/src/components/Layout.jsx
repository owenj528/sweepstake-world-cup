import { Outlet, NavLink, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Home, Trophy, Zap, ArrowLeftRight, User, Shield } from 'lucide-react'

export default function Layout() {
  const { profile, isAdmin } = useAuth()
  const location = useLocation()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Header */}
      <header className="top-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 22 }}>⚽</span>
          <div>
            <div className="font-display" style={{ fontSize: 18, lineHeight: 1 }}>WORLD CUP 2026</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>SWEEPSTAKE</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {profile?.team && (
            <span className="badge badge-gold">🏳️ {profile.team}</span>
          )}
          {isAdmin && (
            <span className="badge badge-red">👑 ADMIN</span>
          )}
        </div>
      </header>

      {/* Page Content */}
      <main style={{ flex: 1 }}>
        <Outlet />
      </main>

      {/* Bottom Navigation */}
      <nav className="bottom-nav">
        <NavLink to="/" end className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <Home />
          <span>Home</span>
        </NavLink>
        <NavLink to="/normal" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <Trophy />
          <span>Sweepstake</span>
        </NavLink>
        <NavLink to="/chaos" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <Zap />
          <span>Chaos</span>
        </NavLink>
        <NavLink to="/trades" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
          <ArrowLeftRight />
          <span>Trades</span>
        </NavLink>
        {isAdmin ? (
          <NavLink to="/admin" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Shield />
            <span>Admin</span>
          </NavLink>
        ) : (
          <NavLink to="/profile" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <User />
            <span>Profile</span>
          </NavLink>
        )}
      </nav>
    </div>
  )
}
