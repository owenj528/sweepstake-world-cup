import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import Layout from './components/Layout'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import NormalSweepstake from './pages/NormalSweepstake'
import ChaosSweepstake from './pages/ChaosSweepstake'
import TradesPage from './pages/TradesPage'
import AdminPage from './pages/AdminPage'
import ProfilePage from './pages/ProfilePage'

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return (
    <div className="loading-screen">
      <div className="spinner" />
      <span>Loading...</span>
    </div>
  )
  if (!user) return <Navigate to="/login" replace />
  return children
}

function AdminRoute({ children }) {
  const { isAdmin, loading } = useAuth()
  if (loading) return null
  if (!isAdmin) return <Navigate to="/" replace />
  return children
}

export default function App() {
  const { user, loading } = useAuth()

  if (loading) return (
    <div className="loading-screen">
      <div style={{ fontSize: 48, marginBottom: 8 }}>⚽</div>
      <div className="spinner" />
      <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>World Cup Sweepstake 2026</span>
    </div>
  )

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<HomePage />} />
        <Route path="normal" element={<NormalSweepstake />} />
        <Route path="chaos" element={<ChaosSweepstake />} />
        <Route path="trades" element={<TradesPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="admin" element={<AdminRoute><AdminPage /></AdminRoute>} />
      </Route>
    </Routes>
  )
}
