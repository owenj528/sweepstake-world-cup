import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function ChaosSweepstake() {
  const { profile } = useAuth()
  const [tab, setTab] = useState('challenges')
  const [challenges, setChallenges] = useState([])
  const [players, setPlayers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAll()
    const sub = supabase.channel('chaos-page')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'challenges' }, loadChallenges)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, loadPlayers)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [])

  async function loadAll() {
    await Promise.all([loadChallenges(), loadPlayers()])
    setLoading(false)
  }

  async function loadChallenges() {
    const { data } = await supabase.from('challenges').select('*').order('completed', { ascending: true }).order('points', { ascending: false })
    if (data) setChallenges(data)
  }

  async function loadPlayers() {
    const { data } = await supabase.from('profiles').select('id, name, team, chaos_points').order('chaos_points', { ascending: false })
    if (data) setPlayers(data)
  }

  if (loading) return <div className="page"><div className="spinner" style={{ marginTop: 48 }} /></div>

  const completed = challenges.filter(c => c.completed)
  const pending = challenges.filter(c => !c.completed)
  const totalPts = completed.reduce((sum, c) => sum + c.points, 0)

  return (
    <div className="page">
      <div style={{ marginBottom: 20 }}>
        <h1 className="font-display" style={{ fontSize: 28 }}>⚡ CHAOS MODE</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>
          Points from silly challenges — not match results!
        </p>
      </div>

      {/* Stats strip */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 20 }}>
        <div className="card" style={{ textAlign: 'center', padding: 12 }}>
          <div className="font-display" style={{ fontSize: 24, color: 'var(--accent-gold)' }}>{completed.length}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>DONE</div>
        </div>
        <div className="card" style={{ textAlign: 'center', padding: 12 }}>
          <div className="font-display" style={{ fontSize: 24, color: 'var(--text-secondary)' }}>{pending.length}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>REMAINING</div>
        </div>
        <div className="card" style={{ textAlign: 'center', padding: 12 }}>
          <div className="font-display" style={{ fontSize: 24, color: 'var(--accent-green)' }}>{totalPts}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>PTS AWARDED</div>
        </div>
      </div>

      <div className="tabs">
        <button className={`tab ${tab === 'challenges' ? 'active' : ''}`} onClick={() => setTab('challenges')}>
          🎯 Challenges
        </button>
        <button className={`tab ${tab === 'leaderboard' ? 'active' : ''}`} onClick={() => setTab('leaderboard')}>
          ⚡ Leaderboard
        </button>
      </div>

      {tab === 'challenges' && (
        <div>
          {pending.length > 0 && (
            <>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
                Pending ({pending.length})
              </div>
              {pending.map(c => <ChallengeCard key={c.id} challenge={c} />)}
            </>
          )}

          {completed.length > 0 && (
            <>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: '16px 0 10px' }}>
                Completed ({completed.length})
              </div>
              {completed.map(c => <ChallengeCard key={c.id} challenge={c} />)}
            </>
          )}

          {challenges.length === 0 && (
            <div className="empty-state">
              <div className="icon">🎯</div>
              <p>No challenges yet. Admin will set these up.</p>
            </div>
          )}
        </div>
      )}

      {tab === 'leaderboard' && (
        <div className="card">
          <div className="section-title" style={{ marginBottom: 12 }}>Chaos Leaderboard</div>
          <div style={{ marginBottom: 12, fontSize: 12, color: 'var(--text-muted)' }}>
            Points earned from completed challenges only — no match results!
          </div>
          {players.map((p, i) => (
            <div key={p.id} className="lb-row" style={{ background: p.id === profile?.id ? 'rgba(245,197,24,0.05)' : '' }}>
              <div className={`lb-rank ${i === 0 ? 'lb-rank-1' : i === 1 ? 'lb-rank-2' : i === 2 ? 'lb-rank-3' : 'lb-rank-other'}`}>
                {i + 1}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14 }}>
                  {p.name} {p.id === profile?.id && <span style={{ fontSize: 10, color: 'var(--accent-gold)' }}>(you)</span>}
                </div>
                {p.team && <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{p.team}</div>}
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, color: i < 3 ? 'var(--accent-gold)' : 'var(--text-primary)' }}>
                {p.chaos_points} <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 400 }}>pts</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function ChallengeCard({ challenge: c }) {
  return (
    <div className={`challenge-card ${c.completed ? 'completed' : ''}`}>
      <div className="challenge-icon">{c.icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
          {c.name}
          {c.completed && <span style={{ fontSize: 14 }}>✅</span>}
        </div>
        {c.description && <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{c.description}</div>}
        {c.completed && c.completed_by_team && (
          <div style={{ fontSize: 11, color: 'var(--accent-green)', marginTop: 4, fontWeight: 600 }}>
            🏳️ {c.completed_by_team}
          </div>
        )}
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{
          fontWeight: 700,
          fontSize: 15,
          color: c.completed ? 'var(--accent-green)' : 'var(--accent-gold)'
        }}>
          {c.points}
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>pts</div>
      </div>
    </div>
  )
}
