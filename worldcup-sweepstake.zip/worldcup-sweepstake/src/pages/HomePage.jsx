import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { Trophy, Zap, ArrowLeftRight, Shield, RefreshCw } from 'lucide-react'
import { format, parseISO, isAfter, isBefore, addHours } from 'date-fns'

export default function HomePage() {
  const { profile, isAdmin } = useAuth()
  const [normalLB, setNormalLB] = useState([])
  const [chaosLB, setChaosLB] = useState([])
  const [upcomingMatches, setUpcomingMatches] = useState([])
  const [liveMatches, setLiveMatches] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    loadAll()

    // Realtime subscriptions
    const profileSub = supabase.channel('home-profiles')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, loadLeaderboards)
      .subscribe()

    const matchSub = supabase.channel('home-matches')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, loadMatches)
      .subscribe()

    return () => {
      supabase.removeChannel(profileSub)
      supabase.removeChannel(matchSub)
    }
  }, [])

  async function loadAll() {
    await Promise.all([loadLeaderboards(), loadMatches()])
    setLoading(false)
  }

  async function loadLeaderboards() {
    const { data } = await supabase
      .from('profiles')
      .select('id, name, team, normal_points, chaos_points')
      .order('normal_points', { ascending: false })

    if (data) {
      setNormalLB([...data].sort((a, b) => b.normal_points - a.normal_points))
      setChaosLB([...data].sort((a, b) => b.chaos_points - a.chaos_points))
    }
  }

  async function loadMatches() {
    const now = new Date().toISOString()
    const { data } = await supabase
      .from('matches')
      .select('*')
      .order('date', { ascending: true })

    if (data) {
      setLiveMatches(data.filter(m => m.status === 'live'))
      setUpcomingMatches(data.filter(m => m.status === 'scheduled' && isAfter(parseISO(m.date), new Date())).slice(0, 5))
    }
  }

  async function handleRefresh() {
    setRefreshing(true)
    await loadAll()
    setRefreshing(false)
  }

  if (loading) return (
    <div className="page" style={{ paddingTop: 32 }}>
      <div className="spinner" /><p style={{ textAlign: 'center', marginTop: 16, color: 'var(--text-secondary)' }}>Loading...</p>
    </div>
  )

  return (
    <div className="page">
      {/* Welcome Banner */}
      <div className="card" style={{
        background: 'linear-gradient(135deg, #0f2040 0%, #1a3a6e 100%)',
        border: '1px solid var(--border-light)',
        marginBottom: 20,
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{ position: 'absolute', right: -10, top: -10, fontSize: 80, opacity: 0.08 }}>⚽</div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 4 }}>Welcome back,</div>
        <div className="font-display" style={{ fontSize: 26 }}>{profile?.name || 'Player'}</div>
        {profile?.team ? (
          <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <span className="badge badge-gold">⚽ {profile.team}</span>
            {profile.team.split(' & ').length > 1 && <span className="badge badge-blue">2 teams</span>}
          </div>
        ) : (
          <div className="alert alert-warning" style={{ marginTop: 10, marginBottom: 0, fontSize: 12 }}>
            ⏳ Waiting for admin to assign your teams
          </div>
        )}
      </div>

      {/* Quick Nav */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
        <Link to="/normal" style={{ textDecoration: 'none' }}>
          <div className="card card-hover" style={{ textAlign: 'center', padding: 16 }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>🏆</div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Sweepstake</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Normal mode</div>
          </div>
        </Link>
        <Link to="/chaos" style={{ textDecoration: 'none' }}>
          <div className="card card-hover" style={{ textAlign: 'center', padding: 16 }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>⚡</div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Chaos Mode</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Challenges</div>
          </div>
        </Link>
        <Link to="/trades" style={{ textDecoration: 'none' }}>
          <div className="card card-hover" style={{ textAlign: 'center', padding: 16 }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>🔄</div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Trades</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Swap teams</div>
          </div>
        </Link>
        {isAdmin ? (
          <Link to="/admin" style={{ textDecoration: 'none' }}>
            <div className="card card-hover" style={{ textAlign: 'center', padding: 16, border: '1px solid rgba(245,197,24,0.3)' }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>👑</div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Admin Panel</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Manage all</div>
            </div>
          </Link>
        ) : (
          <Link to="/profile" style={{ textDecoration: 'none' }}>
            <div className="card card-hover" style={{ textAlign: 'center', padding: 16 }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>👤</div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Profile</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Your stats</div>
            </div>
          </Link>
        )}
      </div>

      {/* Live Matches */}
      {liveMatches.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <div className="section-header">
            <div className="section-title">
              <span className="live-dot" />
              LIVE NOW
            </div>
          </div>
          {liveMatches.map(m => <MatchCard key={m.id} match={m} />)}
        </div>
      )}

      {/* Upcoming Matches */}
      <div style={{ marginBottom: 20 }}>
        <div className="section-header">
          <div className="section-title">📅 NEXT MATCHES</div>
          <button className="btn btn-secondary btn-sm" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw size={13} style={{ animation: refreshing ? 'spin 0.7s linear infinite' : 'none' }} />
          </button>
        </div>
        {upcomingMatches.length === 0 ? (
          <div className="card">
            <p style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center' }}>
              No fixtures loaded yet. Admin can import them from the Admin panel.
            </p>
          </div>
        ) : (
          upcomingMatches.map(m => <MatchCard key={m.id} match={m} />)
        )}
      </div>

      {/* Leaderboards side by side */}
      <div style={{ marginBottom: 20 }}>
        <div className="section-title" style={{ marginBottom: 14 }}>🏆 LEADERBOARDS</div>
        <div className="tabs">
          <LeaderboardTab label="🏆 Normal" data={normalLB} pointsKey="normal_points" currentUserId={profile?.id} />
        </div>
      </div>

      <LeaderboardCard title="🏆 Normal Sweepstake" data={normalLB} pointsKey="normal_points" currentUserId={profile?.id} showTeam />
      <div style={{ height: 16 }} />
      <LeaderboardCard title="⚡ Chaos Mode" data={chaosLB} pointsKey="chaos_points" currentUserId={profile?.id} />
    </div>
  )
}

function MatchCard({ match }) {
  const isLive = match.status === 'live'
  const isFinished = match.status === 'finished'

  return (
    <div className="match-card" style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          {match.stage?.replace(/_/g, ' ')} {match.group_name ? `· ${match.group_name}` : ''}
        </span>
        <span>
          {isLive && <><span className="live-dot" /><span style={{ fontSize: 11, color: 'var(--accent-red)', fontWeight: 700 }}>LIVE</span></>}
          {isFinished && <span style={{ fontSize: 11, color: 'var(--accent-green)', fontWeight: 600 }}>FT</span>}
          {!isLive && !isFinished && (
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              {format(parseISO(match.date), 'MMM d · HH:mm')}
            </span>
          )}
        </span>
      </div>
      <div className="match-teams">
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontWeight: 700, fontSize: 14 }}>{match.home_team}</div>
        </div>
        <div className="match-score" style={{ color: isLive ? 'var(--accent-red)' : isFinished ? 'var(--text-primary)' : 'var(--text-muted)' }}>
          {isLive || isFinished
            ? `${match.home_score ?? 0} - ${match.away_score ?? 0}`
            : 'vs'}
        </div>
        <div style={{ textAlign: 'left' }}>
          <div style={{ fontWeight: 700, fontSize: 14 }}>{match.away_team}</div>
        </div>
      </div>
    </div>
  )
}

function LeaderboardCard({ title, data, pointsKey, currentUserId, showTeam }) {
  return (
    <div className="card">
      <div className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>{title}</div>
      {data.length === 0 ? (
        <p style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center', padding: '16px 0' }}>
          No players yet
        </p>
      ) : (
        data.map((p, i) => (
          <div key={p.id} className="lb-row" style={{ background: p.id === currentUserId ? 'rgba(245,197,24,0.05)' : '' }}>
            <div className={`lb-rank ${i === 0 ? 'lb-rank-1' : i === 1 ? 'lb-rank-2' : i === 2 ? 'lb-rank-3' : 'lb-rank-other'}`}>
              {i + 1}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 600, fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
                {p.name}
                {p.id === currentUserId && <span style={{ fontSize: 10, color: 'var(--accent-gold)' }}>(you)</span>}
              </div>
              {showTeam && p.team && (
                <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{p.team}</div>
              )}
            </div>
            <div style={{ fontWeight: 700, fontSize: 15, color: i < 3 ? 'var(--accent-gold)' : 'var(--text-primary)' }}>
              {p[pointsKey]} <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 400 }}>pts</span>
            </div>
          </div>
        ))
      )}
    </div>
  )
}

// Dummy component to avoid linter error — not used, LeaderboardCard used directly
function LeaderboardTab() { return null }
