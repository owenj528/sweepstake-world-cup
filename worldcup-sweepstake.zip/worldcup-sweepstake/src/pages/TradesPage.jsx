import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { Check, X, Clock, Plus } from 'lucide-react'

export default function TradesPage() {
  const { profile, fetchProfile } = useAuth()
  const [tab, setTab] = useState('open')
  const [trades, setTrades] = useState([])
  const [players, setPlayers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    loadAll()
    const sub = supabase.channel('trades-page')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trades' }, loadTrades)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [profile?.id])

  async function loadAll() {
    await Promise.all([loadTrades(), loadPlayers()])
    setLoading(false)
  }

  async function loadTrades() {
    if (!profile?.id) return
    const { data } = await supabase
      .from('trades')
      .select('*, requester:requester_id(name, team), receiver:receiver_id(name, team)')
      .or(`requester_id.eq.${profile.id},receiver_id.eq.${profile.id}`)
      .order('created_at', { ascending: false })
    if (data) setTrades(data)
  }

  async function loadPlayers() {
    const { data } = await supabase.from('profiles').select('id, name, team').not('team', 'is', null)
    if (data) setPlayers(data)
  }

  async function handleAccept(trade) {
    const { error } = await supabase.from('trades').update({ status: 'accepted' }).eq('id', trade.id)
    if (!error) {
      // Swap the teams
      await supabase.from('profiles').update({ team: trade.receiver_team }).eq('id', trade.requester_id)
      await supabase.from('profiles').update({ team: trade.requester_team }).eq('id', trade.receiver_id)
      await fetchProfile(profile.id)
      await loadAll()
    }
  }

  async function handleReject(tradeId) {
    await supabase.from('trades').update({ status: 'rejected' }).eq('id', tradeId)
    await loadAll()
  }

  async function handleCancel(tradeId) {
    await supabase.from('trades').update({ status: 'cancelled' }).eq('id', tradeId)
    await loadAll()
  }

  if (loading) return <div className="page"><div className="spinner" style={{ marginTop: 48 }} /></div>

  const open = trades.filter(t => t.status === 'pending')
  const history = trades.filter(t => t.status !== 'pending')

  return (
    <div className="page">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 28 }}>🔄 TRADES</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>Swap teams with other players</p>
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowModal(true)}>
          <Plus size={14} /> New Trade
        </button>
      </div>

      {!profile?.team && (
        <div className="alert alert-warning">You don't have a team yet — wait for admin to assign one before trading.</div>
      )}

      <div className="tabs">
        <button className={`tab ${tab === 'open' ? 'active' : ''}`} onClick={() => setTab('open')}>
          Open {open.length > 0 && <span className="badge badge-red" style={{ marginLeft: 4, padding: '1px 5px' }}>{open.length}</span>}
        </button>
        <button className={`tab ${tab === 'history' ? 'active' : ''}`} onClick={() => setTab('history')}>History</button>
      </div>

      {tab === 'open' && (
        <div>
          {open.length === 0 ? (
            <div className="empty-state">
              <div className="icon">🔄</div>
              <p>No open trades. Request one by tapping "New Trade"!</p>
            </div>
          ) : (
            open.map(trade => (
              <TradeCard
                key={trade.id}
                trade={trade}
                currentUserId={profile?.id}
                onAccept={() => handleAccept(trade)}
                onReject={() => handleReject(trade.id)}
                onCancel={() => handleCancel(trade.id)}
              />
            ))
          )}
        </div>
      )}

      {tab === 'history' && (
        <div>
          {history.length === 0 ? (
            <div className="empty-state"><div className="icon">📋</div><p>No trade history yet.</p></div>
          ) : (
            history.map(trade => (
              <TradeCard key={trade.id} trade={trade} currentUserId={profile?.id} readonly />
            ))
          )}
        </div>
      )}

      {showModal && (
        <NewTradeModal
          players={players.filter(p => p.id !== profile?.id)}
          currentPlayer={profile}
          onClose={() => setShowModal(false)}
          onSuccess={() => { setShowModal(false); loadAll() }}
        />
      )}
    </div>
  )
}

function TradeCard({ trade, currentUserId, onAccept, onReject, onCancel, readonly }) {
  const isRequester = trade.requester_id === currentUserId
  const isPending = trade.status === 'pending'
  const canRespond = !isRequester && isPending

  const statusBadge = {
    pending: <span className="badge badge-gold"><Clock size={9} /> Pending</span>,
    accepted: <span className="badge badge-green"><Check size={9} /> Accepted</span>,
    rejected: <span className="badge badge-red"><X size={9} /> Rejected</span>,
    cancelled: <span className="badge badge-gray">Cancelled</span>,
  }

  return (
    <div className="card" style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          {isRequester ? 'You offered a trade to' : 'Trade request from'}
          <strong style={{ color: 'var(--text-secondary)', marginLeft: 4 }}>
            {isRequester ? trade.receiver?.name : trade.requester?.name}
          </strong>
        </div>
        {statusBadge[trade.status]}
      </div>

      {/* Trade visual */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: 8, textAlign: 'center', marginBottom: 12 }}>
        <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: '10px 8px' }}>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 4 }}>
            {isRequester ? 'You give' : `${trade.requester?.name} gives`}
          </div>
          <div style={{ fontWeight: 700, fontSize: 13 }}>{trade.requester_team}</div>
        </div>
        <div style={{ fontSize: 18 }}>🔄</div>
        <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: '10px 8px' }}>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 4 }}>
            {isRequester ? `${trade.receiver?.name} gives` : 'You give'}
          </div>
          <div style={{ fontWeight: 700, fontSize: 13 }}>{trade.receiver_team}</div>
        </div>
      </div>

      {trade.message && (
        <div style={{ fontSize: 12, color: 'var(--text-secondary)', fontStyle: 'italic', marginBottom: 12, padding: '8px', background: 'var(--bg-secondary)', borderRadius: 6 }}>
          "{trade.message}"
        </div>
      )}

      {!readonly && isPending && (
        <div style={{ display: 'flex', gap: 8 }}>
          {canRespond ? (
            <>
              <button className="btn btn-success btn-sm" style={{ flex: 1 }} onClick={onAccept}>
                <Check size={13} /> Accept
              </button>
              <button className="btn btn-danger btn-sm" style={{ flex: 1 }} onClick={onReject}>
                <X size={13} /> Reject
              </button>
            </>
          ) : isRequester ? (
            <button className="btn btn-secondary btn-sm btn-full" onClick={onCancel}>
              Cancel Request
            </button>
          ) : null}
        </div>
      )}
    </div>
  )
}

function NewTradeModal({ players, currentPlayer, onClose, onSuccess }) {
  const [targetId, setTargetId] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const targetPlayer = players.find(p => p.id === targetId)

  async function handleSubmit() {
    if (!targetId) { setError('Select a player to trade with'); return }
    if (!currentPlayer?.team) { setError('You need a team to trade'); return }
    if (!targetPlayer?.team) { setError('That player has no team yet'); return }
    setLoading(true)
    const { error } = await supabase.from('trades').insert({
      requester_id: currentPlayer.id,
      receiver_id: targetId,
      requester_team: currentPlayer.team,
      receiver_team: targetPlayer.team,
      message: message.trim() || null,
      status: 'pending'
    })
    if (error) { setError(error.message); setLoading(false) }
    else onSuccess()
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">🔄 Request Trade</div>

        <div className="form-group">
          <label className="label">Your Team</label>
          <div className="card" style={{ padding: '10px 14px', fontWeight: 700 }}>
            {currentPlayer?.team || 'No team assigned'}
          </div>
        </div>

        <div className="form-group">
          <label className="label">Trade With</label>
          <select className="input" value={targetId} onChange={e => setTargetId(e.target.value)}>
            <option value="">Select a player...</option>
            {players.map(p => (
              <option key={p.id} value={p.id}>{p.name} — {p.team || 'No team'}</option>
            ))}
          </select>
        </div>

        {targetPlayer && (
          <div style={{ marginBottom: 16, display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 8, textAlign: 'center', alignItems: 'center' }}>
            <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>You give</div>
              <div style={{ fontWeight: 700, fontSize: 13, marginTop: 4 }}>{currentPlayer?.team}</div>
            </div>
            <div>🔄</div>
            <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>You get</div>
              <div style={{ fontWeight: 700, fontSize: 13, marginTop: 4 }}>{targetPlayer?.team}</div>
            </div>
          </div>
        )}

        <div className="form-group">
          <label className="label">Message (optional)</label>
          <input className="input" type="text" placeholder="e.g. Come on, fair swap!" value={message} onChange={e => setMessage(e.target.value)} maxLength={100} />
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={handleSubmit} disabled={loading}>
            {loading ? 'Sending...' : '📤 Send Request'}
          </button>
        </div>
      </div>
    </div>
  )
}
