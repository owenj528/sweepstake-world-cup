import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function NormalSweepstake() {
  const { profile } = useAuth()
  const [tab, setTab] = useState('leaderboard')
  const [players, setPlayers] = useState([])
  const [standings, setStandings] = useState({})
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAll()
    const sub = supabase.channel('normal-page')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, loadPlayers)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'group_standings' }, loadStandings)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, loadMatches)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [])

  async function loadAll() {
    await Promise.all([loadPlayers(), loadStandings(), loadMatches()])
    setLoading(false)
  }

  async function loadPlayers() {
    const { data } = await supabase.from('profiles').select('id, name, team, normal_points').order('normal_points', { ascending: false })
    if (data) setPlayers(data)
  }

  async function loadStandings() {
    const { data } = await supabase.from('group_standings').select('*').order('points', { ascending: false })
    if (data) {
      const grouped = {}
      data.forEach(row => {
        if (!grouped[row.group_name]) grouped[row.group_name] = []
        grouped[row.group_name].push(row)
      })
      setStandings(grouped)
    }
  }

  async function loadMatches() {
    const { data } = await supabase.from('matches').select('*').neq('stage', 'group').order('date', { ascending: true })
    if (data) setMatches(data)
  }

  if (loading) return <div className="page"><div className="spinner" style={{ marginTop: 48 }} /></div>

  return (
    <div className="page">
      <div style={{ marginBottom: 20 }}>
        <h1 className="font-display" style={{ fontSize: 28 }}>🏆 SWEEPSTAKE</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>
          Normal mode — your team wins, you win!
        </p>
      </div>

      <div className="tabs">
        {['leaderboard', 'groups', 'bracket', 'teams'].map(t => (
          <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>
            {t === 'leaderboard' ? '🏆' : t === 'groups' ? '📊' : t === 'bracket' ? '🔗' : '👥'}
            {' '}{t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'leaderboard' && <LeaderboardTab players={players} currentUserId={profile?.id} />}
      {tab === 'groups' && <GroupsTab standings={standings} players={players} />}
      {tab === 'bracket' && <BracketTab matches={matches} players={players} />}
      {tab === 'teams' && <TeamsTab players={players} currentUserId={profile?.id} />}
    </div>
  )
}

function LeaderboardTab({ players, currentUserId }) {
  return (
    <div className="card">
      <div className="section-title" style={{ marginBottom: 12 }}>Standings</div>
      <div style={{ marginBottom: 10, fontSize: 12, color: 'var(--text-muted)' }}>
        Points awarded when tournament progresses (admin updates)
      </div>
      {players.map((p, i) => (
        <div key={p.id} className="lb-row" style={{ background: p.id === currentUserId ? 'rgba(245,197,24,0.05)' : '' }}>
          <div className={`lb-rank ${i === 0 ? 'lb-rank-1' : i === 1 ? 'lb-rank-2' : i === 2 ? 'lb-rank-3' : 'lb-rank-other'}`}>
            {i + 1}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 14 }}>
              {p.name} {p.id === currentUserId && <span style={{ fontSize: 10, color: 'var(--accent-gold)' }}>(you)</span>}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2 }}>{p.team || 'No team yet'}</div>
          </div>
          <div style={{ fontWeight: 700, fontSize: 15, color: i < 3 ? 'var(--accent-gold)' : 'var(--text-primary)' }}>
            {p.normal_points} <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 400 }}>pts</span>
          </div>
        </div>
      ))}
    </div>
  )
}

function GroupsTab({ standings, players }) {
  const groups = Object.keys(standings).sort()

  if (groups.length === 0) return (
    <div className="empty-state">
      <div className="icon">📊</div>
      <p>Group standings will appear here once the tournament starts and admin imports fixture data.</p>
    </div>
  )

  // Build a map of team -> player name
  const teamToPlayer = {}
  players.forEach(p => {
    if (p.team) p.team.split(' & ').forEach(t => { teamToPlayer[t.trim()] = p.name })
  })

  return (
    <div>
      {groups.map(group => (
        <div key={group} className="card" style={{ marginBottom: 12 }}>
          <div className="section-title" style={{ fontSize: 15, marginBottom: 10 }}>Group {group}</div>
          <table className="standings-table">
            <thead>
              <tr>
                <th>Team</th>
                <th>P</th>
                <th>W</th>
                <th>D</th>
                <th>L</th>
                <th>GD</th>
                <th>Pts</th>
              </tr>
            </thead>
            <tbody>
              {standings[group].map((row, i) => (
                <tr key={row.team}>
                  <td>
                    <div style={{ fontWeight: i < 2 ? 700 : 400, fontSize: 12 }}>{row.team}</div>
                    {teamToPlayer[row.team] && (
                      <div style={{ fontSize: 10, color: 'var(--accent-gold)' }}>{teamToPlayer[row.team]}</div>
                    )}
                  </td>
                  <td>{row.played}</td>
                  <td>{row.won}</td>
                  <td>{row.drawn}</td>
                  <td>{row.lost}</td>
                  <td style={{ color: row.goal_difference > 0 ? 'var(--accent-green)' : row.goal_difference < 0 ? 'var(--accent-red)' : 'inherit' }}>
                    {row.goal_difference > 0 ? `+${row.goal_difference}` : row.goal_difference}
                  </td>
                  <td style={{ fontWeight: 700 }}>{row.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  )
}

const STAGE_ORDER = ['round_of_16', 'quarter_final', 'semi_final', 'final']
const STAGE_LABEL = {
  round_of_16: 'Round of 16',
  quarter_final: 'Quarter-Finals',
  semi_final: 'Semi-Finals',
  final: 'Final'
}

function BracketTab({ matches, players }) {
  const teamToPlayer = {}
  players.forEach(p => {
    if (p.team) p.team.split(' & ').forEach(t => { teamToPlayer[t.trim()] = p.name })
  })

  const byStage = {}
  matches.forEach(m => {
    if (!byStage[m.stage]) byStage[m.stage] = []
    byStage[m.stage].push(m)
  })

  const stages = STAGE_ORDER.filter(s => byStage[s])

  if (stages.length === 0) return (
    <div className="empty-state">
      <div className="icon">🔗</div>
      <p>Knockout bracket will appear once the tournament reaches the knockout stage.</p>
    </div>
  )

  return (
    <div style={{ overflowX: 'auto' }}>
      <div style={{ display: 'flex', gap: 12, minWidth: stages.length * 170 }}>
        {stages.map(stage => (
          <div key={stage} className="bracket-round">
            <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8, textAlign: 'center' }}>
              {STAGE_LABEL[stage]}
            </div>
            {byStage[stage].map(m => {
              const homeWin = m.status === 'finished' && m.home_score > m.away_score
              const awayWin = m.status === 'finished' && m.away_score > m.home_score
              return (
                <div key={m.id} className="bracket-match">
                  <div className={`bracket-team ${homeWin ? 'winner' : ''}`}>
                    <div>
                      <div>{m.home_team}</div>
                      {teamToPlayer[m.home_team] && <div style={{ fontSize: 9, color: 'var(--accent-gold)' }}>{teamToPlayer[m.home_team]}</div>}
                    </div>
                    {m.status !== 'scheduled' && <span style={{ fontWeight: 700 }}>{m.home_score}</span>}
                  </div>
                  <div className={`bracket-team ${awayWin ? 'winner' : ''}`}>
                    <div>
                      <div>{m.away_team}</div>
                      {teamToPlayer[m.away_team] && <div style={{ fontSize: 9, color: 'var(--accent-gold)' }}>{teamToPlayer[m.away_team]}</div>}
                    </div>
                    {m.status !== 'scheduled' && <span style={{ fontWeight: 700 }}>{m.away_score}</span>}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}

function TeamsTab({ players, currentUserId }) {
  const assigned = players.filter(p => p.team)
  const unassigned = players.filter(p => !p.team)

  return (
    <div>
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="section-title" style={{ fontSize: 15, marginBottom: 12 }}>Team Assignments</div>
        {assigned.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No teams assigned yet — admin will assign 2 teams per person</p>
        ) : (
          assigned.map(p => (
            <div key={p.id} className="lb-row" style={{ background: p.id === currentUserId ? 'rgba(245,197,24,0.05)' : '' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14 }}>
                  {p.name} {p.id === currentUserId && <span style={{ fontSize: 10, color: 'var(--accent-gold)' }}>(you)</span>}
                </div>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{p.team}</div>
            </div>
          ))
        )}
      </div>
      {unassigned.length > 0 && (
        <div className="card">
          <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 8 }}>Awaiting team assignment:</div>
          {unassigned.map(p => (
            <div key={p.id} style={{ padding: '6px 0', fontSize: 13, color: 'var(--text-secondary)', borderBottom: '1px solid var(--border)' }}>
              {p.name}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
