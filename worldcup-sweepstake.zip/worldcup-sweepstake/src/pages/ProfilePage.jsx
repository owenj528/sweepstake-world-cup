import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'
import { useState } from 'react'
import { LogOut, User } from 'lucide-react'

export default function ProfilePage() {
  const { profile, signOut, fetchProfile, user } = useAuth()
  const [editName, setEditName] = useState(false)
  const [name, setName] = useState(profile?.name || '')
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  async function saveName() {
    setSaving(true)
    const { error } = await supabase.from('profiles').update({ name }).eq('id', profile.id)
    if (!error) { await fetchProfile(profile.id); setEditName(false); setMsg('Name updated!') }
    setSaving(false)
  }

  return (
    <div className="page">
      <h1 className="font-display" style={{ fontSize: 28, marginBottom: 20 }}>👤 PROFILE</h1>

      {/* Profile card */}
      <div className="card" style={{ marginBottom: 16, textAlign: 'center', padding: 24 }}>
        <div style={{
          width: 64, height: 64, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--accent-gold), #e8a000)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 12px', fontSize: 28
        }}>
          {profile?.name?.[0]?.toUpperCase() || '?'}
        </div>
        {editName ? (
          <div style={{ display: 'flex', gap: 8, maxWidth: 280, margin: '0 auto' }}>
            <input className="input" value={name} onChange={e => setName(e.target.value)} style={{ flex: 1 }} />
            <button className="btn btn-primary btn-sm" onClick={saveName} disabled={saving}>Save</button>
            <button className="btn btn-secondary btn-sm" onClick={() => setEditName(false)}>✕</button>
          </div>
        ) : (
          <div>
            <div style={{ fontSize: 20, fontWeight: 700 }}>{profile?.name}</div>
            <button style={{ fontSize: 12, color: 'var(--text-muted)', background: 'none', border: 'none', cursor: 'pointer', marginTop: 4 }} onClick={() => setEditName(true)}>
              Edit name
            </button>
          </div>
        )}
        <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>{user?.email}</div>
        {msg && <div className="alert alert-success" style={{ marginTop: 10 }}>{msg}</div>}
      </div>

      {/* Teams */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="section-title" style={{ fontSize: 15, marginBottom: 12 }}>My Teams</div>
        {profile?.team ? (
          <div>
            {profile.team.split(' & ').map((t, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: i === 0 && profile.team.includes('&') ? '1px solid var(--border)' : 'none' }}>
                <span style={{ fontSize: 20 }}>🏳️</span>
                <span style={{ fontWeight: 600 }}>{t.trim()}</span>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No teams assigned yet — admin will assign 2 teams per player before the tournament.</p>
        )}
      </div>

      {/* Points */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <div className="font-display" style={{ fontSize: 32, color: 'var(--accent-gold)' }}>{profile?.normal_points || 0}</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>🏆 SWEEPSTAKE PTS</div>
        </div>
        <div className="card" style={{ textAlign: 'center' }}>
          <div className="font-display" style={{ fontSize: 32, color: 'var(--accent-green)' }}>{profile?.chaos_points || 0}</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>⚡ CHAOS PTS</div>
        </div>
      </div>

      {/* Sign out */}
      <button className="btn btn-secondary btn-full" onClick={signOut} style={{ marginTop: 8 }}>
        <LogOut size={15} /> Sign Out
      </button>
    </div>
  )
}
