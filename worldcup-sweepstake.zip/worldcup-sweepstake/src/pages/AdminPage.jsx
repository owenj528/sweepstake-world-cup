import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { fetchWCMatches, transformMatch, WC2026_TEAMS } from '../lib/footballApi'
import { Check, X, Edit2, RefreshCw, Plus, Trash2, LogOut } from 'lucide-react'

export default function AdminPage() {
  const { signOut } = useAuth()
  const [tab, setTab] = useState('teams')
  const [players, setPlayers] = useState([])
  const [challenges, setChallenges] = useState([])
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    loadAll()
  }, [])

  async function loadAll() {
    await Promise.all([loadPlayers(), loadChallenges()])
    setLoading(false)
  }

  async function loadPlayers() {
    const { data } = await supabase.from('profiles').select('*').order('name')
    if (data) setPlayers(data)
  }

  async function loadChallenges() {
    const { data } = await supabase.from('challenges').select('*').order('completed').order('points', { ascending: false })
    if (data) setChallenges(data)
  }

  function flash(m) { setMsg(m); setTimeout(() => setMsg(''), 3000) }

  if (loading) return <div className="page"><div className="spinner" style={{ marginTop: 48 }} /></div>

  return (
    <div className="page">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 28 }}>👑 ADMIN</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>Full control panel</p>
        </div>
        <button className="btn btn-secondary btn-sm" onClick={signOut}><LogOut size={13} /> Out</button>
      </div>

      {msg && <div className="alert alert-success" style={{ marginBottom: 16 }}>{msg}</div>}

      <div className="tabs" style={{ flexWrap: 'wrap' }}>
        {['teams', 'challenges', 'points', 'fixtures'].map(t => (
          <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)} style={{ fontSize: 12 }}>
            {t === 'teams' ? '👥' : t === 'challenges' ? '🎯' : t === 'points' ? '📊' : '📅'} {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'teams' && <TeamsTab players={players} onRefresh={loadPlayers} onFlash={flash} />}
      {tab === 'challenges' && <ChallengesTab challenges={challenges} players={players} onRefresh={loadChallenges} onFlash={flash} />}
      {tab === 'points' && <PointsTab players={players} onRefresh={loadPlayers} onFlash={flash} />}
      {tab === 'fixtures' && <FixturesTab onFlash={flash} />}
    </div>
  )
}

// ── TEAMS TAB ──────────────────────────────────────────────
function TeamsTab({ players, onRefresh, onFlash }) {
  const [editing, setEditing] = useState(null)
  const [teamVal, setTeamVal] = useState('')
  const [saving, setSaving] = useState(false)

  // Build a list of which teams are already assigned
  const assignedTeams = players.flatMap(p => p.team ? p.team.split(' & ').map(t => t.trim()) : [])

  async function saveTeam(playerId) {
    setSaving(true)
    const { error } = await supabase.from('profiles').update({ team: teamVal.trim() || null }).eq('id', playerId)
    if (!error) { onFlash('Team updated!'); setEditing(null); await onRefresh() }
    setSaving(false)
  }

  return (
    <div>
      <div className="alert alert-info" style={{ marginBottom: 12, fontSize: 12 }}>
        Each player gets 2 teams. Enter them as "Team A &amp; Team B". Example: "Brazil &amp; France"
      </div>
      {players.map(p => (
        <div key={p.id} className="card" style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: editing === p.id ? 10 : 0 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{p.email}</div>
            </div>
            {editing !== p.id && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 13, color: p.team ? 'var(--accent-gold)' : 'var(--text-muted)' }}>
                  {p.team || 'No team'}
                </span>
                <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(p.id); setTeamVal(p.team || '') }}>
                  <Edit2 size={12} />
                </button>
              </div>
            )}
          </div>
          {editing === p.id && (
            <div>
              <div style={{ marginBottom: 8 }}>
                <select className="input" onChange={e => {
                  const v = e.target.value
                  if (!v) return
                  const current = teamVal.split(' & ').filter(Boolean)
                  if (current.length < 2) setTeamVal(current.length === 0 ? v : `${current[0]} & ${v}`)
                  else setTeamVal(`${current[0]} & ${v}`)
                }} defaultValue="">
                  <option value="">Pick a team to add...</option>
                  {WC2026_TEAMS.filter(t => !assignedTeams.includes(t) || teamVal.includes(t)).map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <input
                className="input"
                value={teamVal}
                onChange={e => setTeamVal(e.target.value)}
                placeholder="Brazil & France"
                style={{ marginBottom: 8 }}
              />
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => saveTeam(p.id)} disabled={saving}>
                  <Check size={13} /> Save
                </button>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setEditing(null)}>
                  <X size={13} /> Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// ── CHALLENGES TAB ─────────────────────────────────────────
function ChallengesTab({ challenges, players, onRefresh, onFlash }) {
  const [editing, setEditing] = useState(null)
  const [editData, setEditData] = useState({})
  const [completing, setCompleting] = useState(null)
  const [completingTeam, setCompletingTeam] = useState('')
  const [completingUser, setCompletingUser] = useState('')
  const [showAdd, setShowAdd] = useState(false)

  // All unique teams
  const allTeams = players.flatMap(p => p.team ? p.team.split(' & ').map(t => t.trim()) : []).filter(Boolean)

  async function saveChallenge(c) {
    const { error } = await supabase.from('challenges').update({
      name: editData.name, points: parseInt(editData.points), icon: editData.icon, description: editData.description
    }).eq('id', c.id)
    if (!error) { onFlash('Challenge updated!'); setEditing(null); await onRefresh() }
  }

  async function markComplete(c) {
    if (!completingTeam) { alert('Select a team'); return }
    // Find the player who owns this team
    const player = players.find(p => p.team && p.team.includes(completingTeam))
    const { error } = await supabase.from('challenges').update({
      completed: true,
      completed_at: new Date().toISOString(),
      completed_by_team: completingTeam,
      completed_by_user_id: player?.id || null
    }).eq('id', c.id)
    if (!error) {
      // Add chaos points to that player
      if (player) {
        await supabase.from('profiles').update({ chaos_points: (player.chaos_points || 0) + c.points }).eq('id', player.id)
      }
      onFlash(`✅ "${c.name}" marked complete! +${c.points} pts to ${player?.name || completingTeam}`)
      setCompleting(null); setCompletingTeam('')
      await onRefresh()
    }
  }

  async function undoComplete(c) {
    // Remove chaos points from the player
    const player = players.find(p => p.id === c.completed_by_user_id)
    if (player) {
      await supabase.from('profiles').update({ chaos_points: Math.max(0, (player.chaos_points || 0) - c.points) }).eq('id', player.id)
    }
    const { error } = await supabase.from('challenges').update({
      completed: false, completed_at: null, completed_by_team: null, completed_by_user_id: null
    }).eq('id', c.id)
    if (!error) { onFlash('Challenge undone!'); await onRefresh() }
  }

  async function deleteChallenge(id) {
    if (!confirm('Delete this challenge?')) return
    await supabase.from('challenges').delete().eq('id', id)
    onFlash('Deleted!'); await onRefresh()
  }

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(!showAdd)}>
          <Plus size={13} /> Add Challenge
        </button>
      </div>

      {showAdd && <AddChallengeForm onSave={async (data) => {
        await supabase.from('challenges').insert(data)
        onFlash('Challenge added!'); setShowAdd(false); await onRefresh()
      }} onCancel={() => setShowAdd(false)} />}

      {challenges.map(c => (
        <div key={c.id} className={`card ${c.completed ? '' : ''}`} style={{ marginBottom: 8, borderColor: c.completed ? 'rgba(0,208,132,0.3)' : 'var(--border)' }}>
          {editing === c.id ? (
            <div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                <input className="input" value={editData.icon} onChange={e => setEditData({ ...editData, icon: e.target.value })} placeholder="Icon" style={{ width: 60 }} />
                <input className="input" value={editData.name} onChange={e => setEditData({ ...editData, name: e.target.value })} placeholder="Name" style={{ flex: 1 }} />
                <input className="input" value={editData.points} onChange={e => setEditData({ ...editData, points: e.target.value })} placeholder="Pts" style={{ width: 60 }} type="number" />
              </div>
              <input className="input" value={editData.description || ''} onChange={e => setEditData({ ...editData, description: e.target.value })} placeholder="Description (optional)" style={{ marginBottom: 8 }} />
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => saveChallenge(c)}><Check size={13} /> Save</button>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setEditing(null)}><X size={13} /> Cancel</button>
              </div>
            </div>
          ) : completing === c.id ? (
            <div>
              <div style={{ fontWeight: 600, marginBottom: 10 }}>{c.icon} {c.name} — Mark Complete</div>
              <div className="form-group">
                <label className="label">Which team achieved this?</label>
                <select className="input" value={completingTeam} onChange={e => setCompletingTeam(e.target.value)}>
                  <option value="">Select team...</option>
                  {allTeams.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-success btn-sm" style={{ flex: 1 }} onClick={() => markComplete(c)}>
                  <Check size={13} /> Confirm +{c.points}pts
                </button>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setCompleting(null)}>
                  <X size={13} /> Cancel
                </button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 24, flexShrink: 0 }}>{c.icon}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{c.name}</div>
                {c.completed && (
                  <div style={{ fontSize: 11, color: 'var(--accent-green)', marginTop: 2 }}>
                    ✅ {c.completed_by_team}
                  </div>
                )}
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent-gold)', flexShrink: 0 }}>{c.points}pt</div>
              <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                <button className="btn btn-secondary btn-sm" style={{ padding: '5px 7px' }}
                  onClick={() => { setEditing(c.id); setEditData({ name: c.name, points: c.points, icon: c.icon, description: c.description || '' }) }}>
                  <Edit2 size={11} />
                </button>
                {c.completed ? (
                  <button className="btn btn-danger btn-sm" style={{ padding: '5px 7px' }} onClick={() => undoComplete(c)}>
                    ↩
                  </button>
                ) : (
                  <button className="btn btn-success btn-sm" style={{ padding: '5px 7px' }} onClick={() => setCompleting(c.id)}>
                    <Check size={11} />
                  </button>
                )}
                <button className="btn btn-danger btn-sm" style={{ padding: '5px 7px' }} onClick={() => deleteChallenge(c.id)}>
                  <Trash2 size={11} />
                </button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

function AddChallengeForm({ onSave, onCancel }) {
  const [data, setData] = useState({ name: '', points: 5, icon: '⚽', description: '' })
  return (
    <div className="card" style={{ marginBottom: 12, border: '1px solid var(--accent-blue)' }}>
      <div style={{ fontWeight: 700, marginBottom: 10 }}>New Challenge</div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
        <input className="input" value={data.icon} onChange={e => setData({ ...data, icon: e.target.value })} placeholder="🏆" style={{ width: 60 }} />
        <input className="input" value={data.name} onChange={e => setData({ ...data, name: e.target.value })} placeholder="Challenge name" style={{ flex: 1 }} />
        <input className="input" type="number" value={data.points} onChange={e => setData({ ...data, points: parseInt(e.target.value) })} style={{ width: 60 }} />
      </div>
      <input className="input" value={data.description} onChange={e => setData({ ...data, description: e.target.value })} placeholder="Description (optional)" style={{ marginBottom: 8 }} />
      <div style={{ display: 'flex', gap: 6 }}>
        <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => onSave(data)}>Add</button>
        <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  )
}

// ── POINTS TAB ─────────────────────────────────────────────
function PointsTab({ players, onRefresh, onFlash }) {
  const [editing, setEditing] = useState(null)
  const [vals, setVals] = useState({})

  async function savePoints(p) {
    const { error } = await supabase.from('profiles').update({
      normal_points: parseInt(vals.normal ?? p.normal_points),
      chaos_points: parseInt(vals.chaos ?? p.chaos_points)
    }).eq('id', p.id)
    if (!error) { onFlash('Points updated!'); setEditing(null); await onRefresh() }
  }

  return (
    <div>
      <div className="alert alert-info" style={{ marginBottom: 12, fontSize: 12 }}>
        Manually adjust points for any player. Chaos points auto-update when you mark challenges complete.
      </div>
      {players.map(p => (
        <div key={p.id} className="card" style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: editing === p.id ? 12 : 0 }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
              {p.team && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{p.team}</div>}
            </div>
            {editing !== p.id ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ textAlign: 'right', fontSize: 12 }}>
                  <div>🏆 {p.normal_points}pt</div>
                  <div>⚡ {p.chaos_points}pt</div>
                </div>
                <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(p.id); setVals({ normal: p.normal_points, chaos: p.chaos_points }) }}>
                  <Edit2 size={12} />
                </button>
              </div>
            ) : null}
          </div>
          {editing === p.id && (
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <div>
                  <label className="label">🏆 Normal Pts</label>
                  <input className="input" type="number" value={vals.normal} onChange={e => setVals({ ...vals, normal: e.target.value })} />
                </div>
                <div>
                  <label className="label">⚡ Chaos Pts</label>
                  <input className="input" type="number" value={vals.chaos} onChange={e => setVals({ ...vals, chaos: e.target.value })} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => savePoints(p)}><Check size={13} /> Save</button>
                <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setEditing(null)}><X size={13} /> Cancel</button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// ── FIXTURES TAB ───────────────────────────────────────────
function FixturesTab({ onFlash }) {
  const [importing, setImporting] = useState(false)
  const [matches, setMatches] = useState([])
  const [loaded, setLoaded] = useState(false)
  const [editingMatch, setEditingMatch] = useState(null)
  const [editScore, setEditScore] = useState({ home: '', away: '', status: 'finished' })

  useEffect(() => { loadMatches() }, [])

  async function loadMatches() {
    const { data } = await supabase.from('matches').select('*').order('date', { ascending: true })
    if (data) { setMatches(data); setLoaded(true) }
  }

  async function importFromApi() {
    setImporting(true)
    try {
      const data = await fetchWCMatches()
      if (!data?.matches) {
        onFlash('⚠️ API returned no matches. Check your API key in .env')
        setImporting(false); return
      }
      const transformed = data.matches.map(transformMatch)
      // Upsert by external_id
      const { error } = await supabase.from('matches').upsert(transformed, { onConflict: 'external_id' })
      if (error) onFlash(`Error: ${error.message}`)
      else { onFlash(`✅ Imported ${transformed.length} matches!`); await loadMatches() }
    } catch (e) {
      onFlash(`Error importing: ${e.message}`)
    }
    setImporting(false)
  }

  async function saveScore(match) {
    const { error } = await supabase.from('matches').update({
      home_score: parseInt(editScore.home),
      away_score: parseInt(editScore.away),
      status: editScore.status
    }).eq('id', match.id)
    if (!error) { onFlash('Score updated!'); setEditingMatch(null); await loadMatches() }
  }

  async function deleteMatch(id) {
    if (!confirm('Delete this match?')) return
    await supabase.from('matches').delete().eq('id', id)
    await loadMatches()
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <button className="btn btn-primary btn-sm" onClick={importFromApi} disabled={importing}>
          <RefreshCw size={13} style={{ animation: importing ? 'spin 0.7s linear infinite' : 'none' }} />
          {importing ? 'Importing...' : 'Import from API'}
        </button>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', alignSelf: 'center' }}>
          {matches.length} matches loaded
        </div>
      </div>

      {!loaded ? <div className="spinner" /> : matches.length === 0 ? (
        <div className="empty-state"><div className="icon">📅</div><p>No matches yet. Import from API or add manually.</p></div>
      ) : (
        matches.slice(0, 30).map(m => (
          <div key={m.id} className="card" style={{ marginBottom: 6 }}>
            {editingMatch === m.id ? (
              <div>
                <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8 }}>{m.home_team} vs {m.away_team}</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                  <input className="input" type="number" value={editScore.home} onChange={e => setEditScore({ ...editScore, home: e.target.value })} placeholder="0" />
                  <span style={{ textAlign: 'center', fontWeight: 700 }}>-</span>
                  <input className="input" type="number" value={editScore.away} onChange={e => setEditScore({ ...editScore, away: e.target.value })} placeholder="0" />
                </div>
                <select className="input" value={editScore.status} onChange={e => setEditScore({ ...editScore, status: e.target.value })} style={{ marginBottom: 8 }}>
                  <option value="scheduled">Scheduled</option>
                  <option value="live">Live</option>
                  <option value="finished">Finished</option>
                </select>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => saveScore(m)}><Check size={13} /> Save</button>
                  <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setEditingMatch(null)}><X size={13} /> Cancel</button>
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {m.home_team} vs {m.away_team}
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2 }}>
                    {new Date(m.date).toLocaleDateString()} · {m.stage?.replace(/_/g, ' ')}
                    {m.status !== 'scheduled' && ` · ${m.home_score}-${m.away_score}`}
                  </div>
                </div>
                <span className={`badge ${m.status === 'live' ? 'badge-red' : m.status === 'finished' ? 'badge-green' : 'badge-gray'}`} style={{ flexShrink: 0 }}>
                  {m.status}
                </span>
                <button className="btn btn-secondary btn-sm" style={{ padding: '4px 7px', flexShrink: 0 }}
                  onClick={() => { setEditingMatch(m.id); setEditScore({ home: m.home_score ?? '', away: m.away_score ?? '', status: m.status }) }}>
                  <Edit2 size={11} />
                </button>
              </div>
            )}
          </div>
        ))
      )}
      {matches.length > 30 && <div style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>Showing first 30 of {matches.length} matches</div>}
    </div>
  )
}
