# ⚽ World Cup Sweepstake 2026 — Setup Guide
## Written for mobile — no laptop needed!

---

## What you need (all free)
- Your phone
- An email address
- About 30 minutes

---

## STEP 1 — Create your Supabase database (10 mins)

Supabase is the free database that stores everyone's data.

1. Go to **supabase.com** on your phone
2. Tap **"Start your project"** → Sign up with GitHub or email
3. Tap **"New Project"**
   - Name: `worldcup-sweepstake`
   - Password: make something up and save it
   - Region: pick one close to you (e.g. West Europe)
4. Wait ~2 minutes for it to set up
5. Once ready, go to the left menu → **SQL Editor**
6. Tap **"New Query"**
7. Copy the ENTIRE contents of `supabase_schema.sql` and paste it in
8. Tap **"Run"** (the green button)
   - You should see "Success. No rows returned" — that's correct!

### Get your API keys:
9. Left menu → **Project Settings** → **API**
10. Copy these two things and save them somewhere:
    - **Project URL** (looks like `https://abcdefgh.supabase.co`)
    - **anon public** key (long string of letters)

---

## STEP 2 — Deploy the website (15 mins)

We'll use **Netlify** — free hosting that works perfectly.

### First, put the code on GitHub:

1. Go to **github.com** on your phone → Sign up / Log in
2. Tap **"+"** → **"New repository"**
   - Name: `worldcup-sweepstake`
   - Set to **Public**
   - Tap **"Create repository"**
3. On the next screen, tap **"uploading an existing file"**
4. You need to upload all the files from this project. The easiest way:
   - Use the **GitHub mobile app** (free on App Store/Play Store)
   - Or on a friend's computer for 5 mins

> 💡 **Easiest option**: Ask someone with a laptop to help for just 5 mins to push the code. Or use a free online IDE like **stackblitz.com** — paste the files there and it can deploy directly!

### Deploy on Netlify:

1. Go to **netlify.com** → Sign up (use your GitHub account)
2. Tap **"Add new site"** → **"Import an existing project"**
3. Choose **GitHub** → select `worldcup-sweepstake`
4. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Before deploying, tap **"Advanced"** → **"New variable"** and add:
   ```
   VITE_SUPABASE_URL = (your Project URL from Step 1)
   VITE_SUPABASE_ANON_KEY = (your anon key from Step 1)
   VITE_FOOTBALL_API_KEY = (your football-data.org API token)
   VITE_ADMIN_EMAIL = oj_2010@outlook.com
   ```
6. Tap **"Deploy site"**
7. Wait ~2 minutes → you'll get a URL like `https://amazing-name-123.netlify.app`

**That's your website!** Share that URL with your family.

---

## STEP 3 — Set up your admin account (2 mins)

1. Go to your new website URL
2. Tap **"Sign Up"**
3. Use email: `oj_2010@outlook.com`
4. Check your email and click the confirmation link
5. Log back in — you'll automatically have the 👑 Admin badge

---

## STEP 4 — Import World Cup fixtures (2 mins)

1. Log in as admin
2. Tap **Admin** (bottom nav)
3. Tap the **Fixtures** tab
4. Tap **"Import from API"**
5. All 2026 World Cup matches will load automatically!

---

## STEP 5 — Invite your family

1. Share the website URL with everyone
2. They sign up with their own email + password
3. You go to **Admin → Teams** and assign each person 2 teams
4. They'll see their teams appear instantly!

---

## How to use as Admin day-to-day

### Assign teams:
- Admin → Teams tab
- Find the person
- Pick 2 teams from the dropdown
- Tap Save

### Mark a challenge complete:
- Admin → Challenges tab
- Find the challenge (e.g. "First Red Card")
- Tap the ✅ green button
- Select which team did it
- Points automatically go to that person!

### Undo a mistake:
- Admin → Challenges tab
- Find the completed challenge (green border)
- Tap the ↩ undo button
- Points are automatically removed

### Change points value:
- Admin → Challenges tab
- Tap the ✏️ edit button on any challenge
- Change the points number
- Tap Save

### Manually adjust points:
- Admin → Points tab
- Find the player
- Change normal or chaos points
- Tap Save

### Update a match score:
- Admin → Fixtures tab
- Find the match
- Tap ✏️ edit
- Enter scores and set status to "Finished"

---

## Troubleshooting

**"Missing Supabase environment variables"**
→ You forgot to add the env variables in Netlify. Go to Netlify → Site settings → Environment variables and add them.

**Import from API returns no matches**
→ The World Cup 2026 fixtures may not be published yet on football-data.org (they usually appear a few months before). You can add matches manually in the Fixtures tab.

**Can't log in after signing up**
→ Check your email for a confirmation link from Supabase — you must click it first!

**Someone signed up but I can't see them in Admin**
→ Refresh the page. If still missing, check Supabase → Authentication → Users to confirm they verified their email.

**Website looks broken on iOS**
→ Try opening in Safari (not Chrome) on iPhone for best experience.

---

## Costs: £0

- Supabase free tier: up to 50,000 database rows, 500MB storage ✅
- Netlify free tier: unlimited sites, 100GB bandwidth/month ✅
- football-data.org free tier: 10 requests/minute ✅

You will never need to pay for this for a family sweepstake of 20 people.

---

## Quick links
- Your website: (the Netlify URL you get)
- Supabase dashboard: supabase.com
- Netlify dashboard: netlify.com
- Football data API: football-data.org

---

*Built for the Johnson family World Cup 2026 sweepstake 🏆*
